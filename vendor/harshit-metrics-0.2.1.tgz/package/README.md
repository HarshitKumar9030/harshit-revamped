# harshit-metrics

Advanced TypeScript SDK for [Harshit Metrics](https://metrics.harshit.page).

## Install

```bash
npm install harshit-metrics
```

## Usage

```ts
import { createMetricsClient } from "harshit-metrics";

const metrics = createMetricsClient("mtr_your_api_key", {
  endpoint: "https://metrics.harshit.page/api/collect",
  autoTrackPageviews: true,
  persistQueue: true,
});

metrics.setContext({ app: "marketing-site", environment: "production" });
metrics.track("cta_clicked", { metadata: { section: "hero" } });
```

## Features

- Automatic pageview tracking
- Event batching with configurable batch size
- Retry with exponential backoff
- Optional persisted queue for resilience
- Timing helpers for latency/performance events
- Beacon flush on unload/visibility change

See full docs at `https://metrics.harshit.page/docs/sdk`.
